public class RenamedCloneA {
    public int calculateTotal(int[] numbers) {
        int answer = 0;
        for (int number : numbers) {
            if (number > 0) {
                answer = answer + number;
            }
        }
        int checked = 1;
        return answer;
    }
}
