class ExactClone {
    public int sumPositive(int[] values) {
        int total = 0;
        for (int value : values) {
            if (value > 0) {
                total = total + value;
            }
        }
        return total;
    }
}
