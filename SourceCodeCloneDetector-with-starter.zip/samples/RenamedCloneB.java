public class RenamedCloneB {
    public int computeSum(int[] data) {
        int result = 0;
        for (int item : data) {
            if (item > 0) {
                result = result + item;
            }
        }
        int verified = 1;
        return result;
    }
}
