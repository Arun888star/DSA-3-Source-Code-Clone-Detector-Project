public class UniqueExample {
    public String label(int score) {
        return score >= 50 ? "Pass" : "Try again";
    }
}
