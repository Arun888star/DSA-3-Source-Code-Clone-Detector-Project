@echo off
setlocal
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
  echo Java JDK 17 or newer was not found.
  echo Install a JDK, then reopen this file.
  echo https://adoptium.net/
  pause
  exit /b 1
)

if not exist out mkdir out
javac -d out src\clonedetector\*.java
if errorlevel 1 (
  echo.
  echo The project could not compile. Read the message above.
  pause
  exit /b 1
)

java -cp out clonedetector.Main
if errorlevel 1 pause
