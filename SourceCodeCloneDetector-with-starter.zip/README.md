# Source Code Clone Detector Using Suffix Automaton

A Java Swing desktop application for a Data Structures and Algorithms project. It scans a folder of Java files and finds duplicated token sequences:

- **Type-1 clone**: the token text is identical (comments and whitespace do not matter).
- **Type-2 clone**: the structure is identical after variable, method, and class identifiers are changed to `ID`.

The central data structure is a **Suffix Automaton (SAM)** built over the normalized token stream. The SAM stores every substring of the input in a compact directed graph. States with two or more end positions represent repeated token sequences; those sequences become clone candidates. Each source token retains its file and line number, so candidates can be shown as source locations.

## Project layout

```
src/clonedetector/       application source code
samples/                 intentionally cloned Java files for the demo
sample-output-report.txt example report from the sample folder
```

## Requirements and run

- JDK 17 or newer
- No external libraries

From this project folder in PowerShell:

```powershell
javac -d out src\clonedetector\*.java
java -cp out clonedetector.Main
```

On Windows, the simplest option is to double-click **`StartCloneDetector.bat`**. It checks whether a Java JDK is installed, compiles the project, and opens the application.

In the app, choose the `samples` folder, leave the minimum clone length at `8`, and click **Detect Clones**. Select a group to see its source locations. **Save Report** writes the displayed result to a text file.

## Workflow

1. The user selects a folder; Java files are found recursively.
2. A small lexer removes comments/whitespace and emits tokens with line numbers.
3. Java keywords and punctuation remain unchanged. Other identifiers are normalized to `ID`.
4. Files are joined with unique separator tokens and sent to the suffix automaton.
5. End positions are propagated through SAM suffix links. Repeated states whose longest string meets the threshold are converted into clone instances.
6. Duplicate/overlapping results are filtered and grouped. The raw tokens decide whether a group is Type-1 or Type-2.

## Presentation / viva demo

Open `samples` in the app. Point out the identical `sumPositive` loops in `ExactCloneA.java` and `ExactCloneB.java` (Type-1), then the `calculateTotal` loops in `RenamedCloneA.java` and `RenamedCloneB.java` (Type-2: identifiers differ). Explain that normalization makes the latter token sequences match, while the suffix automaton efficiently finds repeated substrings without comparing every pair of files character by character.

## Notes and scope

This is deliberately a readable college project, rather than a full Java compiler. The lexer understands normal Java comments, strings, chars, identifiers, numbers, operators, and punctuation. Clone detection is exact after normalization; it does not attempt Type-3 (added/deleted statements) or semantic clones.
