package clonedetector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Standard online suffix automaton. Each state represents a set of substrings. */
public final class SuffixAutomaton {
    public static final class State {
        final Map<Integer, Integer> next = new HashMap<>();
        int link = -1;
        int length;
        final List<Integer> ends = new ArrayList<>();
    }
    private final List<State> states = new ArrayList<>();
    private int last;

    public SuffixAutomaton() { states.add(new State()); }
    public List<State> states() { return states; }

    public void extend(int symbol, int position) {
        int current = states.size(); State cur = new State(); cur.length = states.get(last).length + 1; cur.ends.add(position); states.add(cur);
        int p = last;
        while (p != -1 && !states.get(p).next.containsKey(symbol)) { states.get(p).next.put(symbol, current); p = states.get(p).link; }
        if (p == -1) cur.link = 0;
        else {
            int q = states.get(p).next.get(symbol);
            if (states.get(p).length + 1 == states.get(q).length) cur.link = q;
            else {
                int clone = states.size(); State copy = new State(); copy.next.putAll(states.get(q).next); copy.link = states.get(q).link; copy.length = states.get(p).length + 1; states.add(copy);
                while (p != -1 && states.get(p).next.get(symbol) != null && states.get(p).next.get(symbol) == q) { states.get(p).next.put(symbol, clone); p = states.get(p).link; }
                states.get(q).link = cur.link = clone;
            }
        }
        last = current;
    }

    /** Propagate end positions from long states to their suffix links. */
    public void propagateEnds() {
        List<Integer> order = new ArrayList<>(); for (int i = 0; i < states.size(); i++) order.add(i);
        order.sort((a, b) -> Integer.compare(states.get(b).length, states.get(a).length));
        for (int state : order) { int parent = states.get(state).link; if (parent >= 0) states.get(parent).ends.addAll(states.get(state).ends); }
    }
}
