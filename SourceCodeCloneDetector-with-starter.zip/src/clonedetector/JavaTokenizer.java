package clonedetector;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Lightweight lexer: sufficient for token-based clone detection, not a full parser. */
public final class JavaTokenizer {
    private static final Set<String> KEYWORDS = Set.of("abstract","assert","boolean","break","byte","case","catch","char","class","const","continue","default","do","double","else","enum","extends","final","finally","float","for","goto","if","implements","import","instanceof","int","interface","long","native","new","package","private","protected","public","return","short","static","strictfp","super","switch","synchronized","this","throw","throws","transient","try","void","volatile","while","true","false","null","record","sealed","permits","var");
    private static final String[] OPERATORS = {">>>=","<<=",">>=","...","==","!=","<=",">=","++","--","&&","||","+=","-=","*=","/=","%=","<<",">>","->","::","&=","|=","^="};

    private JavaTokenizer() { }

    public static List<Token> tokenize(String text) {
        List<Token> result = new ArrayList<>();
        int i = 0, line = 1;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c)) { if (c == '\n') line++; i++; continue; }
            if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '/') {
                i += 2; while (i < text.length() && text.charAt(i) != '\n') i++; continue;
            }
            if (c == '/' && i + 1 < text.length() && text.charAt(i + 1) == '*') {
                i += 2; while (i + 1 < text.length() && !(text.charAt(i) == '*' && text.charAt(i + 1) == '/')) { if (text.charAt(i++) == '\n') line++; } i = Math.min(text.length(), i + 2); continue;
            }
            int tokenLine = line;
            if (Character.isJavaIdentifierStart(c)) {
                int start = i++; while (i < text.length() && Character.isJavaIdentifierPart(text.charAt(i))) i++;
                String word = text.substring(start, i);
                result.add(new Token(word, KEYWORDS.contains(word) ? word : "ID", tokenLine)); continue;
            }
            if (Character.isDigit(c)) {
                int start = i++; while (i < text.length() && (Character.isLetterOrDigit(text.charAt(i)) || text.charAt(i) == '.' || text.charAt(i) == '_')) i++;
                result.add(new Token(text.substring(start, i), "LITERAL", tokenLine)); continue;
            }
            if (c == '"' || c == '\'') {
                char quote = c; int start = i++;
                while (i < text.length()) { char x = text.charAt(i++); if (x == '\\' && i < text.length()) i++; else if (x == quote) break; else if (x == '\n') line++; }
                result.add(new Token(text.substring(start, i), "LITERAL", tokenLine)); continue;
            }
            String op = null;
            for (String candidate : OPERATORS) if (text.startsWith(candidate, i)) { op = candidate; break; }
            if (op == null) op = String.valueOf(c);
            result.add(new Token(op, op, tokenLine)); i += op.length();
        }
        return result;
    }
}
