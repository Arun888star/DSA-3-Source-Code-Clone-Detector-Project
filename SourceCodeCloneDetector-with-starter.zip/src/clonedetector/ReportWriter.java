package clonedetector;

import java.util.List;

public final class ReportWriter {
    private ReportWriter() { }
    public static String create(List<CloneGroup> groups) {
        long type1 = groups.stream().filter(g -> g.type().equals("Type-1")).count();
        StringBuilder out = new StringBuilder("SOURCE CODE CLONE DETECTOR REPORT\n=================================\n\n");
        out.append("Clone groups: ").append(groups.size()).append("\nType-1 groups: ").append(type1).append("\nType-2 groups: ").append(groups.size() - type1).append("\n\n");
        int n = 1; for (CloneGroup group : groups) { out.append("Clone Group ").append(n++).append(" - ").append(group.type()).append(" (").append(group.tokenCount()).append(" tokens)\n");
            for (CloneGroup.Instance i : group.instances()) out.append("  ").append(i.fileName()).append(": lines ").append(i.startLine()).append('-').append(i.endLine()).append("\n    ").append(i.preview()).append("\n");
            out.append('\n'); }
        return out.toString();
    }
}
