package clonedetector;

import java.util.List;

public record CloneGroup(String type, int tokenCount, List<Instance> instances) {
    public record Instance(String fileName, int startLine, int endLine, String preview) { }
    @Override public String toString() { return type + " clone — " + tokenCount + " tokens — " + instances.size() + " locations"; }
}
