package clonedetector;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingWorker;

public final class CloneDetectorFrame extends JFrame {
    private final JTextField folderField = new JTextField(42);
    private final JSpinner minimum = new JSpinner(new SpinnerNumberModel(8, 3, 200, 1));
    private final JButton detect = new JButton("Detect Clones");
    private final JButton save = new JButton("Save Report");
    private final JLabel status = new JLabel("Choose a folder containing Java files.");
    private final DefaultListModel<CloneGroup> model = new DefaultListModel<>();
    private final JList<CloneGroup> groups = new JList<>(model);
    private final JTextArea details = new JTextArea();
    private List<CloneGroup> results = List.of();

    public CloneDetectorFrame() {
        super("Source Code Clone Detector — Suffix Automaton");
        setDefaultCloseOperation(EXIT_ON_CLOSE); setMinimumSize(new Dimension(900, 560)); setSize(980, 640); setLocationRelativeTo(null);
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        JButton browse = new JButton("Browse…"); controls.add(new JLabel("Source folder:")); controls.add(folderField); controls.add(browse); controls.add(new JLabel("Minimum tokens:")); controls.add(minimum); controls.add(detect); controls.add(save);
        add(controls, BorderLayout.NORTH);
        groups.setBorder(BorderFactory.createTitledBorder("Clone groups"));
        details.setEditable(false); details.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13)); details.setBorder(BorderFactory.createTitledBorder("Selected group details"));
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(groups), new JScrollPane(details)); split.setDividerLocation(310); add(split, BorderLayout.CENTER);
        status.setBorder(BorderFactory.createEmptyBorder(5, 10, 7, 10)); add(status, BorderLayout.SOUTH);
        browse.addActionListener(e -> chooseFolder()); detect.addActionListener(e -> detect()); save.addActionListener(e -> saveReport());
        groups.addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) showSelected(); });
        save.setEnabled(false);
    }
    private void chooseFolder() {
        JFileChooser chooser = new JFileChooser(); chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) folderField.setText(chooser.getSelectedFile().getAbsolutePath());
    }
    private void detect() {
        Path folder; try { folder = Path.of(folderField.getText().trim()); } catch (Exception ex) { showError("Choose a valid folder first."); return; }
        if (!Files.isDirectory(folder)) { showError("Choose a valid folder first."); return; }
        detect.setEnabled(false); save.setEnabled(false); status.setText("Reading files and building suffix automaton…"); model.clear(); details.setText("");
        int min = (Integer) minimum.getValue();
        new SwingWorker<List<CloneGroup>, Void>() {
            @Override protected List<CloneGroup> doInBackground() throws Exception { return new CloneDetector().detect(folder, min); }
            @Override protected void done() { try { results = get(); for (CloneGroup g : results) model.addElement(g); status.setText("Found " + results.size() + " maximal clone groups. Select one for locations."); save.setEnabled(true); }
                catch (Exception ex) { showError("Could not analyze the folder: " + ex.getCause().getMessage()); status.setText("Analysis failed."); }
                finally { detect.setEnabled(true); } }
        }.execute();
    }
    private void showSelected() {
        CloneGroup group = groups.getSelectedValue(); if (group == null) { details.setText(""); return; }
        StringBuilder text = new StringBuilder(group.type()).append(" clone — ").append(group.tokenCount()).append(" normalized tokens\n\n");
        for (CloneGroup.Instance i : group.instances()) text.append(i.fileName()).append("  [lines ").append(i.startLine()).append("–").append(i.endLine()).append("]\n").append(i.preview()).append("\n\n");
        details.setText(text.toString()); details.setCaretPosition(0);
    }
    private void saveReport() {
        JFileChooser chooser = new JFileChooser(); chooser.setSelectedFile(new java.io.File("clone-report.txt"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try { Files.writeString(chooser.getSelectedFile().toPath(), ReportWriter.create(results)); status.setText("Report saved successfully."); }
        catch (IOException ex) { showError("Could not save the report: " + ex.getMessage()); }
    }
    private void showError(String message) { JOptionPane.showMessageDialog(this, message, "Clone Detector", JOptionPane.ERROR_MESSAGE); }
}
