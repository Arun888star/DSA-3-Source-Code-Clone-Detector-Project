package clonedetector;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public final class CloneDetector {
    private record Position(SourceFile file, int tokenIndex) { }

    public List<CloneGroup> detect(Path folder, int minimumTokens) throws IOException {
        List<SourceFile> files = load(folder);
        List<Position> stream = new ArrayList<>(); Map<String, Integer> ids = new HashMap<>(); int nextId = 1;
        SuffixAutomaton sam = new SuffixAutomaton();
        for (int f = 0; f < files.size(); f++) {
            SourceFile file = files.get(f);
            for (int t = 0; t < file.tokens().size(); t++) {
                String normalized = file.tokens().get(t).normalized();
                int id = ids.computeIfAbsent(normalized, ignored -> ids.size() + 1);
                stream.add(new Position(file, t)); sam.extend(id, stream.size() - 1);
            }
            // A unique marker prevents a clone from extending across two files.
            sam.extend(-(f + 1), stream.size()); stream.add(null);
        }
        sam.propagateEnds();
        List<CloneGroup> groups = new ArrayList<>(); Set<String> seen = new HashSet<>();
        for (SuffixAutomaton.State state : sam.states()) {
            int length = state.length;
            if (length < minimumTokens || state.ends.size() < 2) continue;
            List<Integer> ends = state.ends.stream().distinct().sorted().toList();
            List<CloneGroup.Instance> instances = new ArrayList<>();
            Map<String, List<CloneGroup.Instance>> identicalSubgroups = new HashMap<>();
            for (int end : ends) {
                int start = end - length + 1;
                if (start < 0 || end >= stream.size() || stream.get(start) == null || stream.get(end) == null) continue;
                Position first = stream.get(start), last = stream.get(end);
                if (first.file() != last.file() || last.tokenIndex() - first.tokenIndex() + 1 != length) continue;
                CloneGroup.Instance found = instance(first.file(), first.tokenIndex(), last.tokenIndex());
                instances.add(found);
                identicalSubgroups.computeIfAbsent(rawSequence(first.file(), first.tokenIndex(), last.tokenIndex()), ignored -> new ArrayList<>()).add(found);
            }
            if (instances.size() < 2) continue;
            instances.sort(Comparator.comparing(CloneGroup.Instance::fileName).thenComparingInt(CloneGroup.Instance::startLine));
            if (identicalSubgroups.size() == 1) addUnique(groups, seen, "Type-1", length, instances);
            else {
                addUnique(groups, seen, "Type-2", length, instances);
                // A normalized (Type-2) group can contain an exact (Type-1) subgroup.
                for (List<CloneGroup.Instance> exact : identicalSubgroups.values()) if (exact.size() >= 2) addUnique(groups, seen, "Type-1", length, exact);
            }
        }
        groups.sort(Comparator.comparingInt(CloneGroup::tokenCount).reversed());
        return removeContained(groups);
    }

    private static List<SourceFile> load(Path folder) throws IOException {
        try (Stream<Path> paths = Files.walk(folder)) {
            List<Path> javaFiles = paths.filter(p -> p.toString().endsWith(".java")).sorted().toList();
            List<SourceFile> result = new ArrayList<>();
            for (Path path : javaFiles) result.add(new SourceFile(path, JavaTokenizer.tokenize(Files.readString(path, StandardCharsets.UTF_8))));
            return result;
        }
    }
    private static CloneGroup.Instance instance(SourceFile file, int start, int end) {
        List<Token> tokens = file.tokens(); StringBuilder preview = new StringBuilder();
        for (int i = start; i <= end && preview.length() < 90; i++) preview.append(tokens.get(i).raw()).append(' ');
        return new CloneGroup.Instance(file.name(), tokens.get(start).line(), tokens.get(end).line(), preview.toString().trim());
    }
    private static String rawSequence(SourceFile file, int start, int end) {
        StringBuilder out = new StringBuilder();
        for (int i = start; i <= end; i++) out.append(file.tokens().get(i).raw()).append('\u0001');
        return out.toString();
    }
    private static void addUnique(List<CloneGroup> groups, Set<String> seen, String type, int length, List<CloneGroup.Instance> instances) {
        String key = type + ":" + length + ":" + instances.stream().map(i -> i.fileName() + ":" + i.startLine()).reduce("", (a, b) -> a + "|" + b);
        if (seen.add(key)) groups.add(new CloneGroup(type, length, List.copyOf(instances)));
    }
    // Keep maximal groups; smaller groups fully covered by a larger group add little value to the UI.
    private static List<CloneGroup> removeContained(List<CloneGroup> groups) {
        List<CloneGroup> kept = new ArrayList<>();
        for (CloneGroup group : groups) {
            boolean covered = kept.stream().anyMatch(big -> big.instances().size() == group.instances().size() && big.tokenCount() >= group.tokenCount() && sameStarts(big, group));
            if (!covered) kept.add(group);
        }
        return kept;
    }
    private static boolean sameStarts(CloneGroup a, CloneGroup b) {
        for (int i = 0; i < a.instances().size(); i++) if (!a.instances().get(i).fileName().equals(b.instances().get(i).fileName()) || a.instances().get(i).startLine() != b.instances().get(i).startLine()) return false;
        return true;
    }
}
