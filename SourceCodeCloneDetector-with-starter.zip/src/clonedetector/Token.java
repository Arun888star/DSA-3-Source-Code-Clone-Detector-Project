package clonedetector;

/** A lexical token plus the source line used for reporting clone locations. */
public record Token(String raw, String normalized, int line) { }
