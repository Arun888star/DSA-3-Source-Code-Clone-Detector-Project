package clonedetector;

import java.nio.file.Path;
import java.util.List;

public record SourceFile(Path path, List<Token> tokens) {
    public String name() { return path.getFileName().toString(); }
}
